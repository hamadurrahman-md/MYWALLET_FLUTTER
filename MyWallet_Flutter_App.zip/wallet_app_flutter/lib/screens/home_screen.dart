import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("MyWallet")),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Wallet Balance", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            const Text("\$1,200.00", style: TextStyle(fontSize: 32, color: Colors.teal)),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {},
              child: const Text("Add Money"),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {},
              child: const Text("Send Money"),
            ),
            const SizedBox(height: 20),
            const Text("Recent Transactions", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const ListTile(title: Text("Sent \$100 to Alex"), subtitle: Text("2 days ago")),
            const ListTile(title: Text("Added \$500"), subtitle: Text("4 days ago")),
          ],
        ),
      ),
    );
  }
}
